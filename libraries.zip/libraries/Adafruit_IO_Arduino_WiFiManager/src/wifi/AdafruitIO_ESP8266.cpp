//
// Adafruit invests time and resources providing this open source code.
// Please support Adafruit and open source hardware by purchasing
// products from Adafruit!
//
// Copyright (c) 2015-2016 Adafruit Industries
// Authors: Tony DiCola, Todd Treece
// Licensed under the MIT license.
//
// All text above must be included in any redistribution.
//
#ifdef ESP8266

#include "AdafruitIO_ESP8266.h"
#include <WiFiManager.h>		//Added by jaani @ 2018.09.20

AdafruitIO_ESP8266::AdafruitIO_ESP8266(const char *user, const char *key, const char *ssid, const char *pass):AdafruitIO(user, key)
{
  _ssid = ssid;
  _pass = pass;
  _client = new WiFiClientSecure;
  _mqtt = new Adafruit_MQTT_Client(_client, _host, _mqtt_port);
  _http = new HttpClient(*_client, _host, _http_port);
}

AdafruitIO_ESP8266::~AdafruitIO_ESP8266()
{
  if(_client)
    delete _client;
  if(_mqtt)
    delete _mqtt;
}

void AdafruitIO_ESP8266::_connect()
{
	//Hack to use WiFiManager
	//added by Jaani @2018.09.20
	//WiFiManagerParameter custom_io_username("io_username", "Adafruit.IO username", _username, 16);
	//WiFiManagerParameter custom_io_key("io_key", "Adafruit.IO Key", _key, 40, "type=\"password\"");
	
	WiFiManager wifiManager;
	//wifiManager.resetSettings();// uncomment to forget previous wifi manager settings
	wifiManager.autoConnect(_ssid, _pass);
	Serial.println("AIO: Successfull connection to WiFi AP");
/*	
	strcpy(_username, custom_io_username.getValue());
	strcpy(_key, custom_io_key.getValue());


	// save the custom parameters to FS
	if (m_shouldSaveConfig) {
		Serial.println(F("INFO: saving config"));
		DynamicJsonBuffer jsonBuffer;
		JsonObject& json = jsonBuffer.createObject();
		json["io_username"] = _username;
		json["io_key"] = _key;
	  
	  
		File configFile = SPIFFS.open("/config.json", "w");
		if (!configFile) {
		  Serial.println(F("ERROR: failed to open config file for writing"));
		}
		json.printTo(Serial);
		json.printTo(configFile);
		Serial.println();
		configFile.close();
	}
*/
/* //Original code
  delay(100);
  WiFi.begin(_ssid, _pass);
  delay(100);
  _status = AIO_NET_DISCONNECTED;
*/
}

aio_status_t AdafruitIO_ESP8266::networkStatus()
{

  switch(WiFi.status()) {
    case WL_CONNECTED:
      return AIO_NET_CONNECTED;
    case WL_CONNECT_FAILED:
      return AIO_NET_CONNECT_FAILED;
    case WL_IDLE_STATUS:
      return AIO_IDLE;
    default:
      return AIO_NET_DISCONNECTED;
  }

}

const char* AdafruitIO_ESP8266::connectionType()
{
  return "wifi";
}

#endif // ESP8266
